docker compose -f jellyfin-nvidia.yml --env-file jellyfin.env up -d
docker compose -f simplarr-stack.yml --env-file simplarr-stack.env up -d
docker compose -f maintainerr.yml --env-file maintainerr.env up -d
docker compose -f watchtower.yml --env-file watchtower.env up -d